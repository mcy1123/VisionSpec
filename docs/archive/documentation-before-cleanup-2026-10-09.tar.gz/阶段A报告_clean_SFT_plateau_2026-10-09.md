# 阶段 A 执行报告：clean SFT plateau 曲线

日期：2026-10-09
对应计划：`后续计划_视频OPD_2026-10-08.md` §3（阶段 A：A1/A2/A3）
状态：**已完成，判定点为 step1000**

## 1. 做了什么

按 A1 从**相同初始头、相同 439 行 train 划分**重训视频 SFT，保存 step500/1000/1500；
按 A2 在真正独立的 `video_fresh30` 上做 fp32 评测。

重训是必需的：`head_video439` 原本 6000 步、每 500 步存一次，但**只剩 step1000**，
计划表里那条曲线的 step500/1500 检查点已不存在。而且那条曲线测的是
`video_heldout_30`——它的 30 行**全部落在 `pool_499` 的 train 划分内**（即
`head_video439` 训练时见过），所以是一条记忆曲线而非泛化曲线。

重训配方与 `scripts/76_video_sft439.sh` 逐项一致（同初始头、同 439 行、同目标函数/
reveal 先验/block 布局、`--max-anchors 96 --lr 3e-4 --seed 0`），唯一差别是
`--steps 1500`。`train_head_video.py` 没有依赖总步数的调度（lr 固定、reveal 按
`seed+step` 播种、permutation 只在开头抽一次），因此前 1500 步应复现原运行的
step500/1000/1500。

## 2. 复现门禁：通过（统计等价，非逐位相同）

前半程 loss 轨迹与原始日志 `logs/76_video_sft439.log` 对得上：

| step | 原始 log 76 | 本次重训 |
|---:|---:|---:|
| 1 | 0.1172 | 0.1172 |
| 50 | 4.2685 | 4.2689 |
| 100 | 4.0244 | 4.0246 |
| 150 | 4.0122 | 4.0122 |
| 400 | 3.7319 | 3.7316 |
| 450 | 3.6852 | 3.6852 |
| 500 | 3.3811 | 3.3809 |

差异在 ~1e-4 量级，属 GPU 归约/内核非确定性（`train_head_video.py` 未开
`use_deterministic_algorithms`，且 GPU 0 当时与他人任务共享）。**后果**：重训
step1000 与原 `head_video439/step1000` **md5 不同**，权重全局
`mean|Δ|/mean|w| = 1.4e-3`（单张量最大相对差 ~2.8%）——混沌放大的正常结果。

因此额外用**同一套协议**评了原 `head_video439/step1000` 作为 warm 参照。两者：

| | 长度 mean τ | 长度 median τ | 逐样本差异 |
|---|---:|---:|---|
| 重训 step1000 | 3.5785 | 3.6111 | 均值 +0.0017，t +1.00，**29 行中仅 1 行不同** |
| 原 `head_video439/step1000` | 3.5767 | 3.6111 | 基准 |

即：**重训在统计上与 warm start 不可区分**，配方复现成立。

## 3. 主结果：clean 曲线

协议：`video_fresh30` 30 行，首行 warmup 丢弃（n=29），fp32，GLANCE tree b63/k8，
`max_new=1024`，greedy 跑到 EOS，`--ar` 开启做逐 token 无损门禁。

| checkpoint | n | mean τ | median τ | sd | min | max | EOS 命中 | 轮数中位 | 生成长度中位 | fp32 lossless |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| step500 | 29 | 3.5389 | 3.4600 | 0.2554 | 3.0787 | 4.0556 | 29/29 | 76 | 260 | **30/30** |
| **step1000** | 29 | **3.5785** | **3.6111** | 0.2330 | 3.1852 | 4.0000 | 29/29 | 77 | 260 | **30/30** |
| step1500 | 29 | 3.5246 | 3.5167 | 0.2490 | 3.0455 | 4.0345 | 29/29 | 77 | 260 | **30/30** |
| warm 参照（原 step1000） | 29 | 3.5767 | 3.6111 | 0.2335 | 3.1852 | 4.0000 | 29/29 | — | 260 | **30/30** |

逐样本配对差（n=29，同一样本集）：

| 对比 | mean Δτ | median Δτ | t | 正向样本 |
|---|---:|---:|---:|---:|
| step1000 − step500 | +0.0396 | +0.0408 | +1.56 | 17/29 |
| step1500 − step500 | −0.0143 | −0.0357 | −0.50 | 10/29 |
| step1500 − step1000 | **−0.0538** | −0.0388 | −2.06 | 8/29 |

**四个 checkpoint 的 fp32 lossless 门禁全部 30/30 逐 token 一致，无一行失配**
——所以 A2 的"不一致则结果无效"条件没有触发任何一条。

## 4. A3 判定

计划预注册的三条分支：

- ~~最大差 <0.03 τ 且无单调上升 → 确认 plateau~~
- ~~仍单调上升 → 继续 SFT~~
- **先升后降 → 选 clean 泛化峰值** ← 命中

实测：`mean τ` 跨 step500/1000/1500 的极差为 **0.0538 > 0.03**，且形状是
**先升后降**（3.5389 → 3.5785 → 3.5246）。

> **VERDICT：不是 plateau，是"先升后降"。取 clean 泛化峰值 = `step1000`
> （mean τ 3.5785）。**

## 5. 这条结论改了什么

1. **计划 §2 的怀疑被证实。** 旧表（heldout_30）说 step500–1500 已压平
   （3.6464 / 3.6408 / 3.6383，极差 0.0081），所以计划只敢写"更接近早期泛化最优"、
   "不能写成已被严格证明的 plateau"。换成 clean 集后**极差放大到 0.0538**，曲线
   出现真实峰值。污染确实把曲线压平了。
2. **step1000 这个起点保住了，但理由换了。** 计划 §2 是"猜测它接近泛化最优"；
   现在是"clean 集上实测的泛化峰值"，且 step1500 相对它的下降有统计支持
   （t −2.06，18/29 行退化）。
3. **过拟合在 step1500 之前就开始了**，不需要"为了满足 6 epochs 继续过拟合"——
   与计划 §3 A3 第三条的精神一致。
4. **不建议继续调 SFT 步数**：峰值两侧都已量到，继续训只会落在下降段。

## 6. 两个必须记录的坑（影响阶段 B/C 设计）

### 6.1 训练/评测特征路径不一致（本轮**故意**保留）

`train_head_video.py:109` 走 `common.target_context`（`use_cache=False`）。据
`视觉适配诊断_2026-10-05.md` §1.2，该路径下**文本位置的特征对视频输入逐位无关**
（相对 L2 变化 0.0000），而评测 `glance.decode.generate` 走 cache 路径，文本位置
依赖视频（0.1318）。即：本轮所有视频头都在"文本行不依赖视频"的特征上训练，却在
"文本行依赖视频"的特征上评测。

本轮**刻意没有修**，因为阶段 A 的任务是复现 `head_video439` 这条血脉、量它的
clean 曲线；换路径就不叫复现了。`--aligned-forward`（`target_context_aligned`
经 `verify_aligned_to_decode` 断言与 decode prefill 逐位一致）是已存在的正确路径，
`train_fresh_video.py --feature-path cached` 也走 cache。

### 6.2 阶段 C 的潜在混淆

阶段 C 计划对比"同预算继续 SFT" vs "paper-faithful OPD"。但
`opd_train_video.py` 在 `--aligned-forward` 下用**decode 一致**路径（2×2 四臂正是
这么跑的），而"继续 SFT"若仍走 `train_head_video.py` 就是**不一致**路径。这样
两条臂差的就不只是方法，还差特征路径。

**建议**：阶段 C 开工前先决定——要么给 continue-SFT 臂加 aligned/cached 路径，
要么 OPD 臂也退回历史路径；二者必须同口径。这一条计划 §4/§5 未覆盖。

## 7. 产物

| 类型 | 路径 |
|---|---|
| 重训检查点 | `/mnt/local/mcy/GLANCE/checkpoints/head_video439_plateau/{step500,step1000,step1500}` |
| 逐样本评测 JSON | `/mnt/local/mcy/GLANCE/results/phaseA/sft439_step{500,1000,1500}_fresh30_tree_float32.json` |
| warm 参照 JSON | `/mnt/local/mcy/GLANCE/results/phaseA/warmstart_v439_step1000_fresh30_tree_float32.json` |
| A3 判定汇总 | `/mnt/local/mcy/GLANCE/results/phaseA/summary_phaseA.json` |
| 重训脚本 | `repro/run_phaseA_sft_plateau.sh` |
| 评测脚本 | `repro/run_phaseA_eval.sh` |
| 判定脚本 | `repro/summarize_phaseA.py` |
| 训练日志 | `/mnt/local/mcy/GLANCE/logs/phaseA_sft439.{log,jsonl}` |

运行环境：GPU 0（与他人共享），训练 26.9 分钟 / 1500 步，四次评测合计约 75 分钟。
