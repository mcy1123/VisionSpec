# 阶段 A4 执行报告：aligned SFT 重新定峰

日期：2026-10-09
对应计划：`后续计划_视频OPD_2026-10-08.md` §3.1（A4.1–A4.4）
状态：**已完成，aligned 泛化峰值 = `step1000`（mean τ 3.7377）**
前置：`repro/check_context_interface.py`（特征路径门禁）、`阶段A报告_clean_SFT_plateau_2026-10-09.md`（legacy 基线）

## 1. 为什么必须重做

阶段 A 的 step500/1000/1500 全部由旧的 `common.target_context`（`use_cache=False`，
无显式 mask）路径训练。在 `video_fresh30` 上实测（bf16，训练同口径）：

| 路径 | 置零视频后**文本位置** hidden `max\|Δ\|` |
|---|---:|
| 旧 `target_context` | **0.000e+00**（3/3 行） |
| `target_context_cached`（= decode 路径） | 2.440e+02 / 3.190e+02 / 9.778e+03 |

即历史视频头**在"文本行不依赖视频"的特征上训练，却在"文本行依赖视频"的特征上评测**。
所以阶段 A 的曲线不能作为 paper-faithful OPD 的起点。

同时确认两条对齐实现是同一个对象，因此两臂可共用一个 target prefill 接口：

| 对比 | `max\|Δ\|` | 逐位相同 | cos |
|---|---:|---|---:|
| `target_context_cached` vs `target_context_aligned` | **0.000e+00** | 是（3/3 行） | 1.000000 |

## 2. 改了什么

`train_head_video.py` 新增 `--feature-path {uncached,cached}`：

- **默认 `uncached`** —— 历史路径一字未改，所有既有数字仍可复现；
- `cached` 走 `common.target_context_cached`（decode 一致）。

A4 相对阶段 A **只改这一个变量**：同初始头 `checkpoints/head`、同 439 行 train 划分、
同目标函数/reveal 先验/block 布局、同 `--max-anchors 96 --lr 3e-4 --seed 0`，
`--steps 1500 --save-every 250`。

训练日志确认：`feature path: cached (target_context_cached)`。训练 25.2 分钟。
loss 轨迹与旧路径明显不同（step1 **0.0825** vs 旧路径 0.1172），说明特征路径确实
改变了训练信号，而不是数值噪声。

## 3. 主结果：aligned 曲线

协议：`video_fresh30` 30 行，首行 warmup 丢弃（n=29），fp32，GLANCE tree b63/k8，
`max_new=1024`，greedy 跑到 EOS，`--ar` 逐 token 无损门禁。

| checkpoint | n | mean τ | median τ | sd | min | max | EOS | 轮数中位 | 生成长度中位 | lossless |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| step250 | 29 | 3.5840 | 3.5571 | 0.2586 | 3.0787 | 4.0519 | 29/29 | 75 | 260 | **30/30** |
| step500 | 29 | 3.6517 | 3.6562 | 0.2558 | 3.1264 | 4.2222 | 29/29 | 74 | 260 | **30/30** |
| step750 | 29 | 3.7125 | 3.7111 | 0.2484 | 3.2000 | 4.2222 | 29/29 | 71 | 260 | **30/30** |
| **step1000** | 29 | **3.7377** | **3.7778** | 0.2369 | 3.3086 | 4.1714 | 29/29 | 75 | 260 | **30/30** |
| step1250 | 29 | 3.7129 | 3.7429 | 0.3069 | 3.1529 | 4.5000 | 29/29 | 72 | 260 | **30/30** |
| step1500 | 29 | 3.6776 | 3.7015 | 0.2541 | 3.1136 | 4.2222 | 29/29 | 73 | 260 | **30/30** |

**6 个 checkpoint 全部 30/30 逐 token 无损，无一行失配。**

## 4. A4.4 判定

与 A3 同一套预注册规则：

- ~~极差 <0.03 且非单调上升 → plateau~~
- ~~单调上升 → 继续 SFT~~
- **先升后降 → 取 clean 泛化峰值** ← 命中

实测极差 **0.1537**（远超 0.03），形状为**先升后降**。

> **VERDICT：aligned 泛化峰值 = `step1000`，mean τ 3.7377。**

峰值显著性（逐样本配对，n=29）：

| 对比 | mean Δτ | t | 正向 |
|---|---:|---:|---:|
| step1000 − step250 | **+0.1537** | +4.70 | 22/29 |
| step1000 − step500 | **+0.0860** | +3.41 | 18/29 |
| step1000 − step750 | +0.0251 | +1.01 | 13/29 |
| step1250 − step1000 | −0.0248 | −0.74 | 11/29 |
| step1500 − step1000 | −0.0601 | −1.97 | 10/29 |

读法：**step750–1250 是一个统计上平坦的宽峰**（相邻差 0.025，t≈1），真正的显著结构
是 250→1000 的上升（+0.1537，t=4.70）与 1000→1500 的下降（−0.0601，t=−1.97）。
按规则取峰点 `step1000`。

## 5. 最重要的一条：特征路径修复本身就是大效应

同一步数上 aligned 与 legacy 的逐样本配对（n=29）：

| step | legacy（阶段 A） | aligned（A4） | Δτ | t | 正向 |
|---:|---:|---:|---:|---:|---:|
| 500 | 3.5389 | 3.6517 | **+0.1128** | +5.33 | 20/29 |
| 1000 | 3.5785 | **3.7377** | **+0.1592** | +7.30 | 27/29 |
| 1500 | 3.5246 | 3.6776 | **+0.1530** | +5.29 | 23/29 |

**仅修训练/评测特征路径不一致，就拿到 +0.11 ~ +0.16 τ（t = 5.3 ~ 7.3）。**

对照本项目此前追踪的量级：2×2 的 online 主效应是 `+0.0710 τ`，而所有 OPD arm 相对
warm 都是负的（−0.27 左右）。`+0.159 / +0.071 ≈ **2.2 倍**`——**这是同一量级内更大的
效应，不是「大一个数量级」**（初稿的「大一个量级」表述已按计划 §10.9 更正）。

对 2×2 结论的正确读法（不推翻，但要限定）：

- 2×2 的四个 arm 训练时用 `--aligned-forward`，但**初始化自 legacy 训练的
  `head_video439/step1000`**，评测也在 aligned 路径上。它们从 3.5785 掉到约 3.30，
  这是 OPD 训练本身造成的退化，方向不变。
- 但那个"warm start = 3.5687"本身是**特征路径不匹配的产物**。修好之后同一位置的
  起跑线是 **3.7377**，高了 +0.16。
- 因此 §6/§7 的 Phase C/D 必须在**新的、更高的**起跑线上重新做；此前"OPD 有害"的
  幅度里，有多少是特征路径惩罚、有多少是 loss 语义，现在才第一次可以干净地区分。

## 6. 对阶段 C 的直接影响

- **起点**：`head_video439_aligned/step1000`（mean τ 3.7377），替换原计划的
  `head_video439/step1000` / `head_video439_plateau/step1000`。
- **三臂**（`no-training start` / `aligned continue-SFT` / `paper-faithful OPD`）
  现在必须在 aligned 路径上跑；`aligned continue-SFT` 用
  `train_head_video.py --feature-path cached`，与 A4 完全同口径。
- **判据** `Δτ = OPD − aligned continue-SFT >= +0.05` 保持不变。
- 注意起跑线抬到 3.74 后，视频侧已接近该项目在 GLANCE_v2 里记录的"8B+1B 上边界
  τ≈3.2~3.5"之上，可提升空间变小，这一点在解释负结果时必须写清楚。

## 7. 产物

| 类型 | 路径 |
|---|---|
| aligned 检查点 | `/mnt/local/mcy/GLANCE/checkpoints/head_video439_aligned/{step250,500,750,1000,1250,1500}` |
| 逐样本评测 JSON | `/mnt/local/mcy/GLANCE/results/phaseA4/sft439_step{250,500,750,1000,1250,1500}_fresh30_tree_float32.json` |
| A4.4 判定汇总 | `/mnt/local/mcy/GLANCE/results/phaseA4/summary_phaseA4.{json,log}` |
| 特征路径门禁 | `/mnt/local/mcy/GLANCE/results/phaseA4/context_interface_gate.json` |
| 训练脚本 | `repro/run_phaseA4_aligned_sft.sh` |
| 评测脚本 | `repro/run_phaseA_eval.sh`（复用于 A4） |
| 判定脚本 | `repro/summarize_phaseA.py`（复用于 A4） |
| 训练日志 | `/mnt/local/mcy/GLANCE/logs/phaseA4_sft439.{log,jsonl}` |

环境：GPU 0（与他人共享），训练 25.2 分钟 / 1500 步，六次评测合计约 2.2 小时。

## 8. 仍未做（硬前提）

`video_fresh30` 已被用于 A4 定峰，自此只能算 **validation**；剩余 30 条 heldout 也已
进入大量历史结果，**现有 60 条 heldout 都不是严格 untouched test**。最终宣称
"视频 OPD 有效"之前必须另冻一批未参与任何选点的新视频测试集（计划 §5.1）。
