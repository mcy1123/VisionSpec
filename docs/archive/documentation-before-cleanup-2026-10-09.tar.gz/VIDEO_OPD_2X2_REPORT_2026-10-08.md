# Video OPD：online freshness × verifier topology 诊断

日期：2026-10-08

## 结论

Draft-OPD 在论文里有效、当前 GLANCE 视频 OPD 无效，不能只归因于“视频训练没有在线
rollout”。在线化确实有正向作用，但只追回了很小一部分性能；当前视频 loss 与论文 loss
的差异，尤其 teacher top-k 截断和完全缺失的 rejected reverse-KL stream，才是现阶段最强的
解释。

本轮 2×2 的 online 主效应为 **+0.0710 τ**（配对 95% CI
`[+0.0477,+0.0943]`），说明 rollout freshness 是真因素；但最佳 arm 仍比 warm start
低 **−0.2704 τ**。改变 chain/tree 训练拓扑没有恢复收益：online+chain 与 online+tree
最终几乎相同（3.2993 vs 3.2991）。

## 实验设计

- 训练集：`pool_499` 的 train split，排除 30 条既定 holdout，共 409 条。
- 初始化：`head_video439/step1000`。
- 四臂：`frozen/online × chain/tree`。
- 除两个因子外统一：seed 0、200 step、每步 24 anchors、顺序 rollout 最多 32 round、
  block 16、tree b63/k8、lr 3e-4、aligned target forward。
- frozen 使用不可训练的初始化 head 每步重新产生 proposal；online 每步使用正在更新的 head。
- loss 保持当前视频配方不变，以隔离 rollout/topology：accepted token 上 Bernoulli forward
  KL；首个 rejected offset 上 teacher top-64 support 的重归一化 forward KL；无 reverse KL。
- 主评测：真正独立的 `video_fresh30`，GLANCE tree b63/k8，fp32。每个 arm 30 条，首条
  warmup 不进聚合，因此 n=29。
- warm start 引用已完成的 fp32 lossless audit；其两个 shard 各丢一条 warmup，故与 arm
  比较使用共同的 n=28。

## 主结果

| rollout | 训练 verifier | fresh30 mean τ | median τ | 相对 warm（配对 n=28） |
|---|---:|---:|---:|---:|
| frozen | chain | 3.2672 | 3.2881 | −0.3025 |
| frozen | tree | 3.1891 | 3.1982 | −0.3825 |
| online | chain | 3.2993 | 3.3051 | −0.2712 |
| online | tree | 3.2991 | 3.3069 | −0.2704 |
| warm start | — | **3.5687** | **3.6108** | — |

四个 arm 相对 warm 的配对差均为负；没有任何 arm 在共同样本上严格胜过 warm（有少量
数值相等样本）。

### 2×2 配对效应

| contrast | mean Δτ | 95% CI | t | 正/平（n=29） |
|---|---:|---:|---:|---:|
| online − frozen，chain 内 | +0.0321 | [−0.0014,+0.0655] | 1.96 | 17/4 |
| online − frozen，tree 内 | **+0.1100** | **[+0.0795,+0.1405]** | 7.39 | 27/1 |
| online 主效应 | **+0.0710** | **[+0.0477,+0.0943]** | 6.24 | 25/1 |
| tree 主效应 | −0.0391 | [−0.0691,−0.0092] | −2.68 | 8/1 |
| interaction | +0.0779 | [+0.0340,+0.1218] | 3.64 | 23/0 |

这些是单 seed、200-step 诊断的配对区间，不能替代多 seed 最终置信区间；但 effect 的方向
足以排除“只要改成 online 就会复现论文收益”。

## 训练分布揭示了什么

| arm | accepted positions / anchor | rejected positions / anchor | inexact teacher |
|---|---:|---:|---:|
| frozen+chain | 1.444 | 1.000 | 13.86% |
| frozen+tree | 2.720 | 1.000 | 15.52% |
| online+chain | 1.255 | 1.000 | **18.02%** |
| online+tree | 2.332 | 1.000 | **17.55%** |

1. tree 的确把 accepted 监督密度提高了约一倍，但最终 τ 没有提高。这说明问题不是简单的
   “accepted 正样本太少”，而是 loss 优化方向与 tree 接受长度不充分一致。
2. online 后，proposal token 落在 teacher top-64 外的比例明显增加。当前实现只能用
   `log(1-sum(top-k))` 上界代替真实 teacher 概率；恰恰在最需要精确 online feedback 的
   状态上，teacher 信号变得更不精确。
3. 每个 anchor 的 rejected stream 固定只有一个 top-k forward-KL 位置；训练日志中
   `n_k3_rej=0`。也就是说，这个实验虽叫 OPD，但其 rejected 侧并没有论文原始机制中的
   reverse KL。

## 为什么论文有效，而这里仍无效

### 1. 论文的 online rollout 是必要条件，但不是唯一条件

论文每轮用当前 draft policy 做 target-assisted rollout，再从 verification 暴露的 anchor
replay。本轮 online 主效应 +0.071 直接验证了 freshness 的作用；旧视频实现只反复消费
warm-start 静态 pool，确实丢失了这部分收益。

但 +0.071 远小于相对 warm 的约 −0.27，因此“静态 pool”只能解释一部分差距。

### 2. 当前视频目标不是论文的 acceptance-aware mixed KL

原论文使用：

- accepted positions：full-vocabulary forward KL；
- rejected suffix：full-vocabulary reverse KL，而不是只取首个位置；
- block 内权重 `γ=0.8`；
- accepted/rejected 两个 stream 等权；
- target 对 draft-induced prefix 直接打分，无 top-k teacher 截断。

当前视频配方则是：

- accepted：单 token vs 其余词表的 Bernoulli KL；
- rejected：只取第一个拒绝位置，并改成 teacher top-64 support 上的 forward KL；
- reverse stream 为空；
- `γ=0.9`；
- teacher top-64 外的 proposal 用剩余概率质量上界近似。

这不是小的实现误差，而是优化目标已经变了。本轮 online 恰好把 inexact teacher 提高到
约 18%，说明截断偏差会随 on-policy 分布漂移而加重。

### 3. tree 结构不是当前失败的充分解释

如果失败主要来自“论文 chain、GLANCE tree”的不匹配，则 matched tree rollout 应明显优于
chain rollout。结果没有：online+tree 与 online+chain 几乎相等；tree 主效应甚至为负。
因此下一步不应继续只调 tree budget/branch，而应先修 teacher scoring 和 KL。

### 4. 视频工况更难，且训练规模更小

论文是纯文本、同模态 Qwen3，DFlash warm τ 约 5.19；当前视频 warm τ 只有 3.57，长自由
文本响应中第一个错误更频繁。论文还使用 16K prompts、8 epochs；本轮只有 409 行和 200
step。规模差异可能放大问题，但旧的 2000-step 静态视频 OPD 同样退化，所以规模不是单因。

## 下一步判别实验

完整执行计划与预注册判据见 `后续计划_视频OPD_2026-10-08.md`。

优先级最高的不是再放大这套 top-k loss，而是实现一个真正的 paper-faithful scoring arm：

1. target 在 draft-induced prefix 上在线打分；
2. 不截断 teacher vocabulary；
3. accepted full-vocab forward KL；
4. rejected suffix full-vocab reverse KL；
5. `γ=0.8`、两个 stream 等权；
6. 与同预算 continue-SFT、当前 online+tree 做三臂，至少 3 seeds。

若显存/吞吐不允许全词表，可先做明确标注的近似 arm（top-k + tail bucket），但不能再把
top-k 内重归一化当作论文 full-vocabulary KL。

## 产物

- 在线/frozen rollout 实现：`repro/opd_online_rollout.py`
- 训练入口扩展：`repro/opd_train_video.py`
- 纯逻辑测试：`repro/test_opd_online_rollout.py`
- 四臂启动脚本：`repro/run_video_opd_2x2.sh`
- fp32 评测脚本：`repro/eval_video_opd_2x2.sh`
- 汇总脚本：`repro/summarize_video_opd_2x2.py`
- 结构化结果：`/mnt/local/mcy/GLANCE/results/opd_video_2x2/summary_s200_seed0_r32_a24_v2.json`

备注：第一次 v2 前的短跑与一次 bf16 评测被审计主动中止。bf16 下不同 head 产生了不同
输出长度，不能作为 lossless τ 比较；本文只报告后续 fp32 结果。
